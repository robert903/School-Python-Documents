def lengthoflist(lst):
	len=0
	for el in lst:
		len +=1
	return len
	
def sum1(lst):
	if lst==[]:
		return 0
	else:
		return lst[0]+sum1(lst[1:])
		
def sum2(lst):
	sum=0
	for el in lst:
		sum+=el
	return sum
	
def sum3(lst):
	sum=0
	while lst!=[]:
		sum+=lst[0]
		lst=lst[1:]
	return sum