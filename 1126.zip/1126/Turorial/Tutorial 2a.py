import math

#QUESTION 1
def smaller(x,y):
	if x<y:
		return x
	else:
		return y

def smallest(x,y,z):
    if smaller(x,y)<z:
        return smaller(x,y),"is smallest"
    else:
        return z, "is smallest"
        
def tiniest(a,b,c):
	if (a and b)<c:
		if a < b:
			return a
		else:
			return b
	else:
		return c 
		
		
# QUESTION 2

def smallest_angleT(sideA,sideB,sideC):
	angleA=(sideB**2+sideC**2-sideA**2)/(2.0*sideB*sideC)
	angleB=(sideA**2+sideC**2-sideB**2)/(2.0*sideA*sideC)
	angleC=(sideA**2+sideB**2-sideC**2)/(2.0*sideA*sideB)
	SmallestAng=smallest(angleA,angleB,angleC)
	return  math.acos(SmallestAng)
	
	
	
	#QUESTION 3
