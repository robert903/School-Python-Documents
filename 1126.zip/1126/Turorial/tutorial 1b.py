# coding: utf-8
def calcfah(c):
	return (9/5.0*c+32)
	
	
	
#is cold day

def is_coldday(t):
	if t<50:
		return True
	else:
		return False
		
		
def double(num):
	return num*2
	
	
def smaller(num1,num2):
	if num1<num2:
		return num1, "is smaller"
	else:
			return num2," is smaller"
			
def negative(num1,num2):
	if num1<0:
		return 1
	else:
		return num2