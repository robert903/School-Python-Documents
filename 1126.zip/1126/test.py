# coding: utf-8
def print_R(x):
	result=''
	while x>=0:
		if x%2==0:
			result=result+'R'
		else:
			result ='R'+'R'
		x=x-1
	return result