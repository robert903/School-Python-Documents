# coding: utf-8
'''positive integer and returns sum of all integers between itself and one inclusive-- recursively'''

def sumint(num):
	if num>=0:
		return num+ sumint(num-1)
	else:
		return 0





def intr(num):
	if num>=1:
		for x in range(0,num+1):
			num=x+x
		return num
	else:
		return 0
	


#sum of even integers between 1&num
def even(num):
	if num==0:
		return 0
	elif num%2==0:
		return num + even(num-1)
	else:
		return even (num-1)
		
		
def iteven(num):
	sum=0
	for x in range (1,num+1):
		if num%2==0:
			sum +=x
			
	return sum