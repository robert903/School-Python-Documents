def isOdd(num): #1
    if num%2==0 and num>0:
        return False
    else:
        return True


def getLast(num):   #2
    if num>0:
        return num%10


def allButLast(num):    #3
    if num>0:
        return num/10


def numDigits(num):     #4
    counter=1
    if num<1 and num==0:
        return 0
    else:
        return counter+ numDigits(allButLast(num))

def isPrime(num):			#5
		even = num%2==0
		odd = num%3==0
		if num>0 and num%2!=0 and num%3!=0 or num==3:
			return True
		else:
			return False
			
			#3 reads as not prime... bug... everything else works

def reversenum(num):
	if num==0:
		return 0
	else:
		return reversenum(numDigits(num-1))+getLast(num)