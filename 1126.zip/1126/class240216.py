def evenNums(upperlim): #v1
	evenlist=[]
	for num in xrange(upperlim):
		if num%2==0:
			evenlist+=[num]
		return evenlist
		
		
		
		
		'''x+=1 is same as xx+1'''
		
def evenNums2(upperlim):
	even=[x for x in xrange(upperlim) if x%2==0]
	return  even

def evenNumsRec(upperlim):
	if upperlim==0:
		return []
	elif upperlim%2==0:
		return [upperlim]+evenNumsRec(upperlim-2)
	else:
		return evenNumsRec(upperlim-1)
		
		
		
def char(num):
	return chr(num)
	
def ordinal(char):
	return ord(char)
	

