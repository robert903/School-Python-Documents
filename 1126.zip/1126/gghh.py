def what_am_(x):
	if x==0:
		return True
	else