def power(n):       #number 1
    if n<=0:
        return 0
    else:
        return n**n


def sumSeries(n):           #number2
    risen=power(n)
    if n<=0:
        return 0
    else:
        return power(n) + sumSeries(n-1)


def div(num1,num2):         #3div right
    if num1<num2:
        return 0
    else:
        counter=1+div(num1-num2,num2)
        return counter

def mod(num1,num2):
    if num1<num2:
        return num1
    else:
        return mod(num1-num2,num2)

def lastDigit(num1): 
	return mod(num1,10) 
	
def allButLast(num1):
	return div(num1,10) 


def sumDigits(n):           #4c SWEAR TO GOD IDK HOW I GOT THIS TO WORK ON FIRST TRY
    summer=lastDigit(n)
    if summer==0:
        return 0
    else:
        return sumDigits(allButLast(n)) + lastDigit(n)
        
        
 
 
	#Write  a  python  function  is valid  that  checks  if  the  
	
def is_valid(id):
	if id >1000 and id<6999 and sumDigits(id)%7==0:
		return True
	else:
		return False
			