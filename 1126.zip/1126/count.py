# coding: utf-8
def count(n):
	if n>0:
		print n
		return count(n+1)
	elif n==20:
		return 20
	else: return 0