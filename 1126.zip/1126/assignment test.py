def getLast(num):
	return num%10