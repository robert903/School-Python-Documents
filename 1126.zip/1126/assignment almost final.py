def isOdd(num): #1
    if num%2==0:
        return False
    else:
        return True


def getLast(num):   #2
    if num>0:
        return num%10


def allButLast(num):    #3
    if num>0:
        return num/10


def numDigits(num):     #4
    counter=1
    if num<1 and num==0:
        return 0
    else:
        return counter+ numDigits(allButLast(num))

def isPrime(num):			#5
    for i in range(2,num):
        if (num%i)==0:
            return False
    else:
        return True


def reverseNum(num):    #6
    final=0
    numofdigits=numDigits(num)
    for x in range (numofdigits):
			 #if getLast(num)==0:
			 	#return 0
			 #else:
        final=final +(getLast(num)*pow(10, numofdigits-(x+1)))
        num = allButLast(num)
    return final


def allDigitsOdd(num):      #7
    lastnumodd=isOdd(getLast(num))#returns true if last number odd
    if num<1:
        return True
    elif lastnumodd==False:
        return False
    elif lastnumodd==True:
        if allButLast(num)==0:
            return True
        return allDigitsOdd(allButLast(num))
    else:
        return True

def revAndSum(num):     #8
    if num<=0:
        return 0
    else:
     return num+reverseNum(num)

def revAndPrime(num):       #9
    if allDigitsOdd(revAndSum(num))==True and isPrime(revAndSum(num))==True:
        return True

def RAPlist(num):       #10
    final= [x for x in range(1,num+1) if revAndPrime(x)==True]
    return final