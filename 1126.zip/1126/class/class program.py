# coding: utf-8
import math

def sqrt(num):
	guess=1
	prod=calcprod(guess)
	goodguess=compare(prod,num)
	if goodguess:
		return guess
	else:
		improveguess(guess,num)
		return guess