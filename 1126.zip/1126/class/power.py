'''def power(n):
	def raise (e):
		if e==1:
			return n
		else:
			return n*raise (e-1)
	return raise (n)'''
	

def power(n):
	result=1
	for e in range(n):
		result*=n
	return result
	
def powerv3(n):
	
	result=1
	e=n
	while e>o:
		result*=n
		e-=1
	return result