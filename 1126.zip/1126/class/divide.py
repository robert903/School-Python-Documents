# coding: utf-8
def divide(p,q):
	div=0
	while p>=q:
		p=p-q
		div=div+div
	return div
	
#WRITE OVER N FIX

def mod(p,q):
	while p>q:
		p=p-q
	return p