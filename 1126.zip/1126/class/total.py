# coding: utf-8
#ADD 1 TO TOTAL WHILE X IS LESS THAN 10
def range():
	x=0
	total=0
	while x<10:
		x=x+1
		total=total+x
	return total