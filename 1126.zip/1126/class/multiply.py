# coding: utf-8
def product(x,y):
	mul=0
	while y>0:
		mul=mul+x
		y=y-1
	return mul
	
	
	
	
#tomorrow use minus for devision and devide x by y