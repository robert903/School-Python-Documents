# coding: utf-8
def multiply(p,q):
	product=0
	for x in xrange(q):
		product = product + p
	return product
	
def _raise(p,q):
	power=1
	for x in xrange(q):
		power= power*p
	return power