import math

# coding: utf-8
def sqrt(num):
	def calcprod(guess):
	    return guess*guess
	    
	def compare(prod,num):
	    return prod==num
	    
	def close_enough(guess,num,error):
	    return math.fabs(calcprod(guess)-num) < error
	    
	def improveguess (guess,num):
	 	return (num+guess/num)/2.0
	 	
	guess=1
	
	def goodguess(guess,num,error):
		#return compare(calcprod(guess),num) or close_enough(guess,num,error)
		while not goodguess(guess,num,error):
			guess = improveguess(guess,num)
		return guess
		

#determines whether our guess is the square root of number