def larger(num1,num2):
	if num1<num2:
		return num2, "is larger"
	else:
		return num1, "is larger"
		
def smaller(num1,num2):
 	if num1>num2:
 		return num2, "is smaller"
 	else:
 		return num1, "is smaller"
 		
 		
def compare(num1,num2):
	a= "is larger"
	b= "is smaller"
	if num1>num2:
		return num1,a, num2,b
	else:
		return num2,a, num1,b