# coding: utf-8
'''
parametize things that change

read on local and global functions

elements of recursive function: base case and recursive case

localize recursive function















'''