# coding: utf-8
def factorial(x):
	fac=1
	for x in xrange(1,x+1):
		fac= fac*x
	return fac