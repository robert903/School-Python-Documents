# coding: utf-8
"""Calls itself within itself
EG. N!=N*N(N-1)! WE WANT TO FIND FACTORIALS USING THIS FORMUPLA"""

def fac(p):
	if p==1:
		return 1
	return p*fac(p-1)
	
	
def mul(p,q):
	if q==0:
		return 0
	return p+mul(p,q-1)
	
def divide(p,q):
	if p<q:
		return 0
	return 1+divide(p-q,q)
	

def exp(p,q):
	if q==0:
		return 1
	return p*mul(p,q-1)
	
def rem(p,q):
	if p<q:
		return 0
	return 1+rem(p-q,q)
	
