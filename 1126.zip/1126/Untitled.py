def smaller(x,y):
	if x<y:
		return x
	else:
		return y

def smallest(x,y,z):
    if smaller(x,y)<z:
        return smaller(x,y),"is smallest"
    else:
        return z, "is smallest"