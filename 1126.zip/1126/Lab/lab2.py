# coding: utf-8
import math

def quadratic(a,b,c):
	discriminant= b**2-(4*a*c)
	if discriminant<0:
		return 'No Real Roots'
	elif discriminant>0:
		root1=(-b+(math.sqrt(b**2-4*a*c)))/2*a
		root2=(-b-((b**2-4*a*c)**1/2))/2*a
	if root1>root2:
		return root1
	else:
		return root2