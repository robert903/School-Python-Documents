# coding: utf-8
def squareNum1(a):
	square = a*a
	print square
	
	
def squareNum2(a):
	square = a*a
	return square
	
def mystery(num):
	num=num*2
	newnum=num+2
	return newnum