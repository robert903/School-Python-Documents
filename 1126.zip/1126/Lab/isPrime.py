# coding: utf-8
def robert():
	cat=0
	robert=cat
	boy=cat
	
	return robert==boy
	
	
def boy():
	x=16
	ans=0
	while ans*ans<x:
		ans=ans+1
	print ans