import math

def encode(string):
	arg=str(string)
	if arg[:]=='':
		return ''
	else:
		return  chr(ord(arg[0])+5)+encode(arg[1:])
		
def decode(string):
	if string[:]=='':
		return ''
	else:
		return chr(ord(string[0])-5)+decode(string[1:])
		

def sumlist(lst,function):
	helper=0
	for x in lst:
		helper=helper+function(x)
	return helper
	
def mean(lst):
	if lst=='':
		return 0
	else:
		return sumlist(lst,lambda x:x)/len(lst)


def st_dev(lst):
	if lst=='':
		return ''
	else:
		return math.sqrt(((sumlist(lst,lambda x:x **2))/len(lst)) - (mean(lst))**2)