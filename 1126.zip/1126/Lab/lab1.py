#QUESTION 1
def mystery():
	digit = int(raw_input ('Enter last digit of phone number\n'))
	year = int(raw_input ('Enter your year of birth\n'))
	
	digit= (digit*2+5)*50+1765
	answer = digit - year
	return answer
	
#QUESTION 2
def fuzzbiz(num):
	if num % 5==0 and num % 3==0:
		return 'FuzzBiz'
	elif num % 3==0:
		return 'Fuzz'
	elif num % 5==0:
		return 'Biz'
	else:
		return 'No Fuzz No Biz'
		
#Question 3
def IsLeapYear():
	year= int(raw_input('Enter Year To Test\n'))
	if year % 4==0 and year % 100 !=0:
		return True
	elif year % 400==0:
		return True
	else:
		return False