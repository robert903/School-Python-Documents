'''sum every number between starting point and stopping point'''
# v1
def sumseries(start,stop):
	if start>stop:
		return 0
	else:
		return start+sumseries(start+1,stop)
	
'''sum every number of series'''	
#v2
def sumseries2(start,stop,x):
	if start>stop:
		return 0
	else:
		return start+sumseries2(x(start),stop,x)
		
def add2(n):
	return n+2


#v3
def sumseries3(start,stop,incr,trm):
	if start>stop:
		return 0
	else:
		return trm(start)+sumseries3(incr(start),stop,incr,trm)
		
def add1(n):
	return n+1

def gettrm(n):
	return 2*n+2
	
	
	
'''lambda write anonymous functions

eg lambda x:x+1
		start+sumseries3(incr(start),stop,lambda x:x+1)

in terminal sumseries3(1,6,lambda x:x+1, lambda m:1+2*m)

'''