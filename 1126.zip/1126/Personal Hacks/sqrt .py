# coding: utf-8
def sqrt(num):
	return num**.5